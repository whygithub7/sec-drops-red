const Http = new XMLHttpRequest();
const url = "/static-cache/javascripts/47f840ee846b4a023a9736d4d1675cfacb041460ecc62db7f3859797c7ae4eac";
Http.open("PUT", url);
Http.send();
